//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Patch.rc
//
#define MANIFEST_RESOURCE_ID            1
#define IDR_MAINFRAME                   5
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PATCH_DIALOG                102
#define IDB_BACKGROUND_BITMAP           134
#define IDB_BITMAP_FULLPROGRESSBACKGROUND 138
#define IDB_BITMAP_PATCHLISTSCROLL      140
#define IDB_BITMAP_SCROLLPOINT1         146
#define IDB_BITMAPBAR                   169
#define IDB_BITMAP_STARTNORMAL_JP       172
#define IDB_BITMAP_EXITCLICK_ENG        173
#define IDB_BITMAP_EXITMOVE_ENG         174
#define IDB_BITMAP_EXITNORMAL_ENG       175
#define IDB_BITMAP_EXITCLICK_JP         176
#define IDB_BITMAP_EXITMOVE_JP          177
#define IDB_BITMAP_EXITNORMAL_JP        178
#define IDB_BITMAP_STARTCLICK_ENG       179
#define IDB_BITMAP_STARTMOVE_ENG        180
#define IDB_BITMAP_STARTNORMAL_ENG      181
#define IDB_BITMAP_STARTCLICK_JP        182
#define IDB_BITMAP_STARTMOVE_JP         183
#define IDB_BITMAP_STARTDISABLE_JP      184
#define IDB_BITMAP_EXITDISABLE_ENG      185
#define IDB_BITMAP_EXITDISABLE_JP       186
#define IDB_BITMAP4                     187
#define IDB_BITMAP_STARTDISABLE_ENG     187
#define IDB_BITMAP_EXITNORMAL_KR        188
#define IDB_BITMAP_EXITMOVE_KR          189
#define IDB_BITMAP_EXITDISABLE_KR       190
#define IDB_BITMAP_EXITCLICK_KR         191
#define IDB_BITMAP_STARTCLICK_KR        192
#define IDB_BITMAP_STARTDISABLE_KR      193
#define IDB_BITMAP_STARTMOVE_KR         194
#define IDB_BITMAP_STARTNORMAL_KR       195
#define IDB_BITMAP2                     198
#define IDB_BITMAP3                     199
#define IDB_BITMAP5                     200
#define IDB_BITMAP1                     204
#define IDB_BITMAP6                     205
#define IDB_BITMAP_EXITDISABLE_TW       205
#define IDB_BITMAP_EXITMOVE_TW          206
#define IDB_BITMAP_EXITNORMAL_TW        207
#define IDB_BITMAP_EXITCLICK_TW         208
#define IDB_BITMAP_STARTCLICK_TW        209
#define IDB_BITMAP_STARTDISABLE_TW      210
#define IDB_BITMAP_STARTMOVE_TW         211
#define IDB_BITMAP7                     212
#define IDB_BITMAP_STARTNORMAL_TW       212
#define IDB_BITMAP_EXITNORMAL_USA       213
#define IDB_BITMAP_STARTNORMAL_USA      214
#define IDB_BITMAP_STARTDISABLE_USA     215
#define IDB_BITMAP_STARTMOVE_USA        216
#define IDB_BITMAP_STARTCLICK_USA       217
#define IDB_BITMAP_EXITCLICK_USA        218
#define IDB_BITMAP_EXITDISABLE_USA      219
#define IDB_BITMAP_EXITMOVE_KR1         220
#define IDB_BITMAP_EXITMOVE_USA         220
#define IDC_CURRENT_FILE_PROGRESS       1000
#define IDC_ALL_FILE_PROGRESS           1001
#define IDC_PATCH_EXPLAIN_LIST          1005
#define IDC_CHECK_AUTORUN               1013
#define IDC_EDIT_PATCH_CONTENT          1014
#define IDC_EXPLORER_PATCH_CONTENT_VIEWER 1016
#define IDC_EXPLORER_PATCH_CONTENT_VIEWER2 1018
#define IDC_STATIC_BACKGROUND           1019
#define IDC_PROGRESS_DOWN2              1021
#define IDC_BUTTON_RUN                  1022
#define IDC_BUTTON_STOP                 1023
#define IDC_STATIC_STATUS               1025
#define IDC_EDIT1                       1026
#define IDC_STATICIMAGE                 1027
#define IDC_STATIC_IMAGE                1028
#define IDC_STATIC_VERSION				1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        222
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
