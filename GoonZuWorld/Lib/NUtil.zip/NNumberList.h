//-----------------------------------------------------------------------------
// 2005 ������
//-----------------------------------------------------------------------------

#ifndef _NNUMBERLIST_H
#define _NNUMBERLIST_H

#include "NList.h"

class NNumberList
{
public:
	NNumberList();
	~NNumberList();

	void				CreateNumberList();
	
	int					CheckOutNumber();
	bool				CheckInNumber( int i );

	void				GetNumber();

	void				GetNumber();

public:
	
	NFreeList< int >	m_freelist;
	NList< int >		m_activelist;
};


inline void NNumberList::CreateNumberList( int maxnumber )
{	
	m_freelist.CreateFreeList( maxnumber );

	m_list.CreateList( &m_freelist );


}

inline int NNumberList::CheckOutNumber()
{
	
}

inline void NNumberList::CheckOutNumber( int a )
{
	m_list.PushBackGetData();
}

inline void NNumberList::CheckInNumber( int a )
{
	
}

#endif