#include "graphics.h"

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <ddraw.h>

#include "Helper.h"

