#include "ServerOnStepNotifyDlg.h"
#include "../CommonLogic/TextMgr/TextMgr.h"
#include "../CommonLogic/CommonLogic.h"

#include <Graphic.h>
#include "../../Lib/NGraphics/Graphics.h"
#include <Graphic_Capsule.h>
#include "Client.h"

extern BOOL g_bFullScreen;		// Ǯ��ũ�� ���� 

extern LPDIRECTDRAWSURFACE7 g_lpBackScreen;	// ������ �׷��� ȭ�� ���� ���ǽ�. 

CServerOnStepNotifyDlg g_ServerOnStepNotifyDlg;

extern cltCommonLogic* pclClient;

CServerOnStepNotifyDlg::CServerOnStepNotifyDlg()
{
	m_hDlg = NULL;
	
	m_hLoadingImage = NULL;
	m_hProgress = NULL;
	
	m_bShow = false;

	m_hEditBrush = NULL;

	m_siPercent = 0;
	m_siGameScreenMode=0;

	BackGoundXPos=0;
	BackGoundYPos=0;
	ProgressXPos=0;
	ProgressyPos=0;
}

CServerOnStepNotifyDlg::~CServerOnStepNotifyDlg()
{
	if ( m_hDlg )
	{
		DestroyWindow( m_hDlg );
	}
}

void CServerOnStepNotifyDlg::Create( HINSTANCE hInst, HWND hWnd, SI16 GameMode, SI16 GameScreenMode  )
{
	m_siGameMode = GameMode;

	if ( m_siGameMode != GAMEMODE_CLIENT )
	{
		return;
	}

	m_hParentWnd = hWnd;
	m_siGameScreenMode= GameScreenMode;


	if ( g_bFullScreen )
	{	
		return;
	}

	m_siGameMode = GameMode;

	m_hInst = hInst;
	m_hDlg = CreateDialog( hInst, MAKEINTRESOURCE( IDD_DIALOG_SERVERONSTEPNOTIFY ), hWnd, StaticServerOnStepNotifyDlgProc );

	Hide(); //�ΰ� ȭ�� ���� ����� ���ؼ� ���ܼ� ����
///	Show();
}
void CServerOnStepNotifyDlg::LoadSpr()
{
	GP.LoadSpr("./loading/interface_354x264_00_000.spr",&m_BKSpr );
	GP.LoadSpr("./loading/image_14x28_00_000.spr", &m_ProgressSpr );
}

BOOL CALLBACK CServerOnStepNotifyDlg::StaticServerOnStepNotifyDlgProc( HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
	return g_ServerOnStepNotifyDlg.ServerOnStepNotifyDlgProc( hDlg, iMsg, wParam, lParam );
}

BOOL CALLBACK CServerOnStepNotifyDlg::ServerOnStepNotifyDlgProc( HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam )
{
	switch( iMsg )
	{
	case WM_INITDIALOG:
		{
			InitCommonControls();
			
			m_hDlg = hDlg;

			/*
			HWND hStatic = GetDlgItem( hDlg, IDC_STATIC_LOADINGIMAGE );
			if ( m_hLoadingImage != NULL )
			{
				if( SendMessage( hStatic, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM) m_hLoadingImage ) == NULL )
				{
					int b = 0;
				}
			}
			*/

			m_hProgress = GetDlgItem ( hDlg, IDC_PROGRESS_STEP );

			// EditBrush 
			m_hEditBrush = CreateSolidBrush( COLOR_DIALOG_WHITEBLUE );
			
			SendMessage( m_hProgress, PBM_SETRANGE, 0, MAKELPARAM( 0, 100 ) );
			SendMessage( m_hProgress, PBM_SETPOS, 0, 0 );
			
		}
		return TRUE;
	/*
	case WM_PAINT:
		{
			HDC hdc;
			PAINTSTRUCT ps;
			
			hdc = BeginPaint( hDlg, &ps);
			
			HDC mdc;
			mdc = CreateCompatibleDC( hdc );
			HBITMAP hOldBitmap = (HBITMAP)SelectObject( mdc, m_hLoadingImage );
			BitBlt( hdc, 0, 0, 344, 207, mdc, 0, 0, SRCCOPY );
			SelectObject( mdc, hOldBitmap );
			DeleteDC( mdc );

			EndPaint( hDlg, &ps);			
		}
		break;
	*/
	/*
	case WM_CTLCOLORSTATIC:
		{
			if ( GetDlgItem( hDlg, IDC_STATIC_PROGRESS_PERCENT ) == (HWND)lParam )
			{
				HDC hdc = (HDC)wParam;
				SetTextColor( hdc, COLOR_DIALOG_BLACK );
				SetBkColor( hdc, COLOR_DIALOG_WHITEBLUE);
				return (BOOL)m_hEditBrush;
			}
		}
		break;
	*/

	case WM_COMMAND:
		{
			switch( LOWORD( wParam ) )
			{
			case IDOK:
			case IDCANCEL:
				Hide();
				break;	
			}
		}
		break;

	case WM_CLOSE:
		{
			DestroyWindow( m_hDlg );
		}
		break;

	case WM_DESTROY:
		{
			if ( m_hEditBrush )
			{
				DeleteObject( m_hEditBrush );
				m_hEditBrush = NULL;
			}

			if ( m_hLoadingImage )
			{
				DeleteObject( m_hLoadingImage );
				m_hLoadingImage = NULL;
			}

			m_hDlg = NULL;
		}
		break;
	}

	return FALSE;
}
	
bool CServerOnStepNotifyDlg::IsShow()
{
	return m_bShow;
}

void CServerOnStepNotifyDlg::Show()
{
	if ( m_siGameMode != GAMEMODE_CLIENT )
	{
		return;
	}

	m_bShow = true;
	ShowWindow( m_hDlg, SW_SHOW );

	if ( pclClient->siServiceArea == ConstServiceArea_Korea || pclClient->siServiceArea == ConstServiceArea_Netmarble)
		m_hLoadingImage = (HBITMAP)LoadImage( m_hInst, "GImg/Loading.BMP", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE );
	else if( pclClient->siServiceArea == ConstServiceArea_China )
        m_hLoadingImage = (HBITMAP)LoadImage( m_hInst, "GImg/LoadingC.BMP", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE );
	else
		m_hLoadingImage = (HBITMAP)LoadImage( m_hInst, "GImg/LoadingE.BMP", IMAGE_BITMAP, 0, 0, LR_CREATEDIBSECTION | LR_DEFAULTSIZE | LR_LOADFROMFILE );

	return;
}

void CServerOnStepNotifyDlg::Hide()
{
	if ( m_siGameMode != GAMEMODE_CLIENT )
	{
		return;
	}
	
	m_bShow = false;
	ShowWindow( m_hDlg, SW_HIDE );

	return;
}

void CServerOnStepNotifyDlg::Set( SI32 Percent )
{
	if ( m_siGameMode != GAMEMODE_CLIENT )
	{
		return;
	}

	if ( Percent < 0 )
	{
		Percent = 0;
	}

	m_siPercent = Percent;

	
	
	if ( g_bFullScreen )
	{
		if ( m_siPercent > 100 )
		{
			if ( m_BKSpr.Image )
			{
				GP.FreeSpr( m_BKSpr );
			}

			if ( m_ProgressSpr.Image )
			{
				GP.FreeSpr( m_ProgressSpr );
			}
		}
		else
		{
			Draw();
			
		}

		return;
	}

	if ( m_hDlg == NULL || m_siGameMode != GAMEMODE_CLIENT )
	{
		return;
	}

	if ( Percent > 100 )
	{
		DestroyWindow( m_hDlg );
		return;
	}

	if ( m_hLoadingImage )
	{
		SendMessage( GetDlgItem( m_hDlg, IDC_STATIC_LOADINGIMAGE ), STM_SETIMAGE, IMAGE_BITMAP, (LPARAM) m_hLoadingImage );
	}

	SendMessage( m_hProgress, PBM_SETPOS, Percent, 0 );

	char Buffer[256 ] = "";
	//char* pText = GetTxtFromMgr(2068);
	if ( pclClient->siServiceArea == ConstServiceArea_Korea || pclClient->siServiceArea == ConstServiceArea_Netmarble)
		sprintf( Buffer, "�ε��� - %d%%", Percent );
	else if( pclClient->siServiceArea == ConstServiceArea_China )
		sprintf( Buffer, "Now, Loading - %d%%", Percent );
	else
		sprintf( Buffer, "Now, Loading - %d%%", Percent );

	//sprintf( Buffer,pText, Percent );
	//SetWindowText( GetDlgItem( m_hDlg, IDC_STATIC_PROGRESS_PERCENT ), Buffer );
	SetWindowText( m_hDlg, Buffer );

	return;
}

void CServerOnStepNotifyDlg::Draw()
{
	if( m_BKSpr.Image == NULL ) return;

	if ( m_siGameMode != GAMEMODE_CLIENT )
	{
		return;
	}
	
	SI32 XDrawlocation=0;

	if(m_siGameScreenMode==MODE_GRAPHICS1024_768)
	{
		BackGoundXPos= (1024 - m_BKSpr.clHeader.siXsize ) / 2 + 90;
		BackGoundYPos= (768 - m_BKSpr.clHeader.siYsize ) / 2 + 40;
		ProgressXPos=9+BackGoundXPos;
		ProgressyPos=229+BackGoundYPos;

	}
	else
	{
		BackGoundXPos= (800 - m_BKSpr.clHeader.siXsize ) / 2 + 90;
		BackGoundYPos= (600 - m_BKSpr.clHeader.siYsize ) / 2 + 40;
		ProgressXPos=9+BackGoundXPos;
		ProgressyPos=229+BackGoundYPos;
	}


	int prowidth = m_BKSpr.clHeader.siXsize;
	int curwidth;

	LPDIRECTDRAWSURFACE7 lpBackBuffer = g_graphics.GetBackBuffer();
	if( GP.LockSurface( lpBackBuffer ) == TRUE )
	{
		if ( m_siPercent <= 100 )
		{
			m_BKSpr.PutSprT( BackGoundXPos, BackGoundYPos, 0 );

			XDrawlocation = 0;

			curwidth = ( m_siPercent / 100. ) * m_BKSpr.clHeader.siXsize - 18;

			while( XDrawlocation < curwidth - m_ProgressSpr.clHeader.siXsize )
			{
				m_ProgressSpr.PutSprT( ProgressXPos + XDrawlocation , ProgressyPos, 0 );
				XDrawlocation += m_ProgressSpr.clHeader.siXsize;
			}
			
			m_ProgressSpr.PutSprT( ProgressXPos + curwidth - m_ProgressSpr.clHeader.siXsize, ProgressyPos , 0 );

		}

		GP.UnlockSurface( lpBackBuffer );

		((cltClient *)pclClient)->UpdateScreen( m_hParentWnd, lpBackBuffer, true );
	}

	return;
}